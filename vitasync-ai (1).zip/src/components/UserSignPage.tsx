import React, { useState } from 'react';
import { UserAccount } from '../types';
import {
  User,
  Lock,
  Mail,
  Building2,
  BadgeCheck,
  ShieldCheck,
  UserPlus,
  LogIn,
  LogOut,
  Stethoscope,
  KeyRound,
  Check,
  AlertCircle,
  Sparkles,
  Activity,
  HeartPulse
} from 'lucide-react';

interface UserSignPageProps {
  currentUser: UserAccount | null;
  onLogin: (user: UserAccount) => void;
  onLogout: () => void;
}

export const UserSignPage: React.FC<UserSignPageProps> = ({
  currentUser,
  onLogin,
  onLogout
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState('Attending Physician');
  const [regDepartment, setRegDepartment] = useState('Cardiothoracic Surgery');
  const [regStaffId, setRegStaffId] = useState('MED-9082');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Quick Preset Clinicians for instant demo access
  const presetUsers: UserAccount[] = [
    {
      id: 'USR-101',
      fullName: 'Dr. Eleanor Vance, MD',
      email: 'dr.vance@vitasync.med',
      role: 'Attending Orthopedic Surgeon',
      department: 'Joint Reconstruction & Orthopedics',
      staffId: 'STAFF-8901',
      createdAt: new Date().toISOString()
    },
    {
      id: 'USR-102',
      fullName: 'Sarah Jenkins, RN',
      email: 'nurse.sarah@vitasync.med',
      role: 'Post-Op Charge Nurse',
      department: 'Surgical Intensive Care Unit (SICU)',
      staffId: 'STAFF-4412',
      createdAt: new Date().toISOString()
    },
    {
      id: 'USR-103',
      fullName: 'Dr. Marcus Sterling, MD',
      email: 'dr.sterling@vitasync.med',
      role: 'Chief of Cardiothoracic Surgery',
      department: 'Cardiothoracic Surgery Department',
      staffId: 'STAFF-1002',
      createdAt: new Date().toISOString()
    }
  ];

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword })
      });

      const data = await res.json();
      if (data.success && data.user) {
        onLogin(data.user);
        setSuccessMsg(`Welcome back, ${data.user.fullName}! Authentication successful.`);
      } else {
        setErrorMsg(data.error || 'Invalid credentials. Try using one of the quick clinician presets below.');
      }
    } catch (err: any) {
      console.error('Login error:', err);
      // Fallback local match
      const matched = presetUsers.find(
        (u) => u.email.toLowerCase() === loginEmail.toLowerCase()
      );
      if (matched) {
        onLogin(matched);
        setSuccessMsg(`Authenticated as ${matched.fullName}!`);
      } else {
        setErrorMsg('Authentication server unavailable. Select a quick clinician card below.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: regFullName,
          email: regEmail,
          password: regPassword,
          role: regRole,
          department: regDepartment,
          staffId: regStaffId
        })
      });

      const data = await res.json();
      if (data.success && data.user) {
        onLogin(data.user);
        setSuccessMsg(`Account created for ${data.user.fullName}! Registered into VitaSync Database.`);
      } else {
        setErrorMsg(data.error || 'Registration failed. Email might already be registered.');
      }
    } catch (err: any) {
      console.error('Register error:', err);
      setErrorMsg('Failed to register user to database.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPreset = (user: UserAccount) => {
    setLoginEmail(user.email);
    setLoginPassword('password123');
    onLogin(user);
    setSuccessMsg(`Signed in as ${user.fullName} (${user.role})`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2">
              <span className="bg-blue-600 text-white text-xs font-bold px-2.5 py-1 rounded uppercase tracking-wider">
                Clinical Access Portal
              </span>
              <span className="bg-emerald-500/20 text-emerald-300 text-xs font-semibold px-2.5 py-1 rounded border border-emerald-500/30">
                Database Auth Active
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-2">
              Clinician Authentication & Account Management
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              Secure single sign-on & account registration for hospital surgical staff, post-op nurses, and attending physicians.
            </p>
          </div>

          <div className="p-4 bg-slate-800/90 rounded-xl border border-slate-700 flex items-center space-x-3 shrink-0">
            <div className="p-2.5 bg-blue-600 text-white rounded-lg">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">HIPAA & Clinical Compliance</div>
              <div className="text-[11px] text-slate-400">Encrypted VitaSync Database Storage</div>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      {errorMsg && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-bold flex items-center gap-2">
          <AlertCircle className="h-5 w-5 text-red-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
          <BadgeCheck className="h-5 w-5 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* IF CURRENTLY LOGGED IN: SHOW PROFILE DASHBOARD */}
      {currentUser ? (
        <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-200 pb-6 gap-4">
            <div className="flex items-center space-x-4">
              <div className="h-16 w-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-700 text-white flex items-center justify-center font-black text-2xl shadow-lg shadow-blue-500/20">
                {currentUser.fullName.charAt(0)}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="text-xl font-bold text-slate-900">{currentUser.fullName}</h3>
                  <span className="bg-blue-100 text-blue-800 text-[10px] font-extrabold px-2 py-0.5 rounded border border-blue-200 font-mono">
                    {currentUser.staffId}
                  </span>
                </div>
                <p className="text-xs font-semibold text-blue-700 mt-0.5">{currentUser.role}</p>
                <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                  <Building2 className="h-3.5 w-3.5 text-slate-400" />
                  {currentUser.department}
                </p>
              </div>
            </div>

            <button
              onClick={onLogout}
              className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-bold text-xs border border-red-200 flex items-center space-x-2 transition-all cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign Out Account</span>
            </button>
          </div>

          {/* Account Permissions Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">Account Status</div>
              <div className="text-sm font-extrabold text-emerald-700 mt-1 flex items-center gap-1.5">
                <BadgeCheck className="h-4 w-4 text-emerald-600" /> Active Clinician
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Verified with staff ID {currentUser.staffId}</div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">Database Access</div>
              <div className="text-sm font-extrabold text-slate-900 mt-1 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-blue-600" /> Full Read & Write
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Authorized for VitalsLogs Table</div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">Email Handle</div>
              <div className="text-sm font-bold text-slate-900 mt-1 truncate">{currentUser.email}</div>
              <div className="text-[11px] text-slate-500 mt-1">Primary Notifications Channel</div>
            </div>
          </div>
        </div>
      ) : (
        /* IF NOT LOGGED IN: SHOW AUTH TAB & QUICK PRESETS */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Form (7 cols) */}
          <div className="lg:col-span-7 bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden">
            {/* Tab Header */}
            <div className="flex border-b border-slate-200 bg-slate-50">
              <button
                onClick={() => { setMode('login'); setErrorMsg(null); }}
                className={`flex-1 py-3.5 px-4 text-xs font-extrabold flex items-center justify-center space-x-2 border-b-2 transition-all cursor-pointer ${
                  mode === 'login'
                    ? 'border-blue-600 text-blue-700 bg-white'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <LogIn className="h-4 w-4" />
                <span>Clinician Sign In</span>
              </button>

              <button
                onClick={() => { setMode('register'); setErrorMsg(null); }}
                className={`flex-1 py-3.5 px-4 text-xs font-extrabold flex items-center justify-center space-x-2 border-b-2 transition-all cursor-pointer ${
                  mode === 'register'
                    ? 'border-blue-600 text-blue-700 bg-white'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <UserPlus className="h-4 w-4" />
                <span>Register New Account</span>
              </button>
            </div>

            {/* LOGIN FORM */}
            {mode === 'login' && (
              <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Medical Email Address
                  </label>
                  <div className="relative">
                    <Mail className="h-4 w-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="e.g. dr.vance@vitasync.med"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="h-4 w-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="password"
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer"
                >
                  {loading ? (
                    <span>Authenticating...</span>
                  ) : (
                    <>
                      <LogIn className="h-4 w-4" />
                      <span>Sign In to Clinical Portal</span>
                    </>
                  )}
                </button>
              </form>
            )}

            {/* REGISTER FORM */}
            {mode === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="p-6 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Full Name & Title
                    </label>
                    <input
                      type="text"
                      required
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      placeholder="e.g. Dr. Arthur Pendelton, MD"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Staff Employee ID
                    </label>
                    <input
                      type="text"
                      required
                      value={regStaffId}
                      onChange={(e) => setRegStaffId(e.target.value)}
                      placeholder="e.g. STAFF-9082"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Medical Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="dr.pendelton@vitasync.med"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Account Password
                  </label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Create a secure password"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Clinical Role / Specialty
                    </label>
                    <select
                      value={regRole}
                      onChange={(e) => setRegRole(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                    >
                      <option value="Attending Physician">Attending Physician</option>
                      <option value="Chief Surgical Specialist">Chief Surgical Specialist</option>
                      <option value="Post-Op Charge Nurse">Post-Op Charge Nurse</option>
                      <option value="Anesthesiologist">Anesthesiologist</option>
                      <option value="Surgical Resident">Surgical Resident</option>
                      <option value="Clinical Care Coordinator">Clinical Care Coordinator</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Hospital Department
                    </label>
                    <select
                      value={regDepartment}
                      onChange={(e) => setRegDepartment(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                    >
                      <option value="Cardiothoracic Surgery">Cardiothoracic Surgery</option>
                      <option value="Joint Reconstruction & Orthopedics">Joint Reconstruction & Orthopedics</option>
                      <option value="General & Laparoscopic Surgery">General & Laparoscopic Surgery</option>
                      <option value="Surgical Intensive Care Unit (SICU)">Surgical Intensive Care Unit (SICU)</option>
                      <option value="Neurosurgery Post-Op Ward">Neurosurgery Post-Op Ward</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-3 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer"
                >
                  {loading ? (
                    <span>Saving to Database...</span>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4" />
                      <span>Register Clinician & Save to Database</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

          {/* Quick Preset Clinicians (5 cols) */}
          <div className="lg:col-span-5 space-y-3">
            <div className="bg-slate-900 text-white p-4 rounded-xl flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <KeyRound className="h-4 w-4 text-blue-400" />
                <h4 className="font-bold text-xs">Fast 1-Click Clinician Sign-In</h4>
              </div>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                Preset Accounts
              </span>
            </div>

            <div className="space-y-2">
              {presetUsers.map((user) => (
                <button
                  key={user.id}
                  onClick={() => handleSelectPreset(user)}
                  className="w-full text-left p-3 bg-white hover:bg-blue-50/70 rounded-xl border border-slate-200 hover:border-blue-300 transition-all shadow-sm group cursor-pointer flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 rounded-xl bg-slate-100 group-hover:bg-blue-600 group-hover:text-white text-slate-700 font-bold flex items-center justify-center text-sm transition-colors">
                      {user.fullName.charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900 group-hover:text-blue-900">
                        {user.fullName}
                      </div>
                      <div className="text-[11px] text-blue-600 font-medium">{user.role}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">{user.email}</div>
                    </div>
                  </div>
                  <span className="text-xs text-blue-600 font-bold group-hover:translate-x-1 transition-transform">
                    Sign In &rarr;
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
