import React, { useState } from 'react';
import { Thermometer, Heart, AlertTriangle, Play, Sparkles, CheckCircle2, Flame, Gauge, Zap } from 'lucide-react';
import { PatientProfile } from '../types';

interface VitalsInputFormProps {
  patient: PatientProfile;
  onSubmitVitals: (vitals: {
    patientId: string;
    patientName: string;
    surgeryType: string;
    postOpDay: number;
    temperature: number;
    heartRate: number;
    painLevel: number;
  }) => Promise<void>;
  isAnalyzing: boolean;
}

export const VitalsInputForm: React.FC<VitalsInputFormProps> = ({
  patient,
  onSubmitVitals,
  isAnalyzing
}) => {
  const [formMode, setFormMode] = useState<'card' | 'detailed'>('card');
  const [patientId, setPatientId] = useState(patient.id);
  const [postOpDayInput, setPostOpDayInput] = useState<string>(String(patient.postOpDay || 1));
  const [temperatureInput, setTemperatureInput] = useState<string>('102');
  const [heartRateInput, setHeartRateInput] = useState<string>('108');
  const [painLevelInput, setPainLevelInput] = useState<string>('9');

  // Sync ONLY when patient ID actually changes
  React.useEffect(() => {
    setPatientId(patient.id);
    setPostOpDayInput(String(patient.postOpDay || 1));
  }, [patient.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalTemp = parseFloat(temperatureInput) || 98.6;
    const finalHR = parseFloat(heartRateInput) || 75;
    const finalPain = parseFloat(painLevelInput) || 0;
    const finalPostOp = parseInt(postOpDayInput, 10) || patient.postOpDay || 1;

    await onSubmitVitals({
      patientId,
      patientName: patient.name,
      surgeryType: patient.surgery,
      postOpDay: finalPostOp,
      temperature: finalTemp,
      heartRate: finalHR,
      painLevel: finalPain
    });
  };

  const setPreset = (temp: number, hr: number, pain: number) => {
    setTemperatureInput(String(temp));
    setHeartRateInput(String(hr));
    setPainLevelInput(String(pain));
  };

  const numTemp = parseFloat(temperatureInput) || 0;
  const numHR = parseFloat(heartRateInput) || 0;
  const numPain = parseFloat(painLevelInput) || 0;

  const isTempCritical = numTemp > 101.0;
  const isHRCritical = numHR > 110;
  const isPainCritical = numPain > 8;
  const isAnyCritical = isTempCritical || isHRCritical || isPainCritical;

  const getPainColor = (level: number) => {
    if (level <= 3) return 'bg-emerald-500 text-white';
    if (level <= 6) return 'bg-amber-500 text-white';
    if (level <= 8) return 'bg-orange-600 text-white';
    return 'bg-red-600 text-white animate-pulse';
  };

  return (
    <div className="space-y-4">
      {/* Mode Switcher Banner */}
      <div className="flex items-center justify-between bg-slate-200/80 p-1.5 rounded-xl border border-slate-300/80 text-xs font-bold">
        <button
          type="button"
          onClick={() => setFormMode('card')}
          className={`flex-1 py-1.5 px-3 rounded-lg transition-all cursor-pointer ${
            formMode === 'card'
              ? 'bg-white text-blue-700 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          ✨ Quick Form Card
        </button>
        <button
          type="button"
          onClick={() => setFormMode('detailed')}
          className={`flex-1 py-1.5 px-3 rounded-lg transition-all cursor-pointer ${
            formMode === 'detailed'
              ? 'bg-white text-blue-700 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          ⚙️ Advanced Clinical Controls
        </button>
      </div>

      {/* MODE 1: EXACT MATCH QUICK FORM CARD FROM IMAGE */}
      {formMode === 'card' ? (
        <div className="bg-white rounded-3xl shadow-xl border border-slate-200/80 p-8 space-y-6 max-w-md mx-auto">
          <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tight">VitaSync AI</h2>
            <p className="text-sm font-medium text-slate-500 mt-1">Post-Surgery Recovery Monitor</p>
          </div>

          <div className="pt-2">
            <h3 className="text-xl font-bold text-slate-900">Submit Daily Vitals</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Input 1: Post-Op Day or Patient ID */}
            <div>
              <label className="text-xs font-semibold text-slate-500 block mb-1">
                Post-Op Day / Patient ID
              </label>
              <input
                type="number"
                required
                value={postOpDayInput}
                onChange={(e) => setPostOpDayInput(e.target.value)}
                placeholder="1"
                className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-base font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
              />
            </div>

            {/* Input 2: Heart Rate */}
            <div>
              <label className="text-xs font-semibold text-slate-500 block mb-1">
                Heart Rate (BPM)
              </label>
              <input
                type="number"
                required
                value={heartRateInput}
                onChange={(e) => setHeartRateInput(e.target.value)}
                placeholder="75"
                className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-base font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
              />
            </div>

            {/* Input 3: Temperature */}
            <div>
              <label className="text-xs font-semibold text-slate-500 block mb-1">
                Body Temperature (°F)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={temperatureInput}
                onChange={(e) => setTemperatureInput(e.target.value)}
                placeholder="98.6"
                className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-base font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
              />
            </div>

            {/* Input 4: Pain Level */}
            <div>
              <label className="text-xs font-semibold text-slate-500 block mb-1">
                Pain Level Scale (1 - 10)
              </label>
              <input
                type="number"
                min="0"
                max="10"
                required
                value={painLevelInput}
                onChange={(e) => setPainLevelInput(e.target.value)}
                placeholder="3"
                className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-base font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isAnalyzing}
                className="w-full py-3.5 px-6 rounded-xl font-bold text-base text-white bg-sky-500 hover:bg-sky-600 transition-all shadow-md active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer"
              >
                {isAnalyzing ? (
                  <span>Analyzing Vitals...</span>
                ) : (
                  <span>Analyze Vitals</span>
                )}
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* MODE 2: DETAILED ADVANCED CLINICAL FORM */
        <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
          {/* Form Header */}
          <div className="bg-slate-900 text-white p-4 px-6 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Gauge className="h-5 w-5 text-blue-400" />
              <h3 className="font-bold text-base">Record Patient Vitals</h3>
            </div>
            <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-1 rounded border border-slate-700 font-mono">
              Clinical Database: VitalsLogs
            </span>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Preset Selector for Fast Test Cases */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
                  <Zap className="h-3.5 w-3.5 text-amber-500" />
                  Quick Test Presets (Rule Thresholds)
                </label>
                <span className="text-[11px] text-slate-500">Click to load test parameters</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setPreset(98.6, 74, 3)}
                  className="text-left p-2.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-all text-xs cursor-pointer"
                >
                  <div className="font-bold text-emerald-900 flex items-center justify-between">
                    <span>🟢 Normal</span>
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  </div>
                  <div className="text-[11px] text-emerald-700 mt-1">98.6°F | 74 BPM | 3/10</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPreset(101.8, 88, 4)}
                  className="text-left p-2.5 rounded-lg bg-red-50 hover:bg-red-100 border border-red-200 transition-all text-xs cursor-pointer"
                >
                  <div className="font-bold text-red-900 flex items-center justify-between">
                    <span>🔴 Temp &gt; 101°F</span>
                    <Flame className="h-3.5 w-3.5 text-red-600" />
                  </div>
                  <div className="text-[11px] text-red-700 mt-1">101.8°F | 88 BPM | 4/10</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPreset(99.2, 118, 5)}
                  className="text-left p-2.5 rounded-lg bg-red-50 hover:bg-red-100 border border-red-200 transition-all text-xs cursor-pointer"
                >
                  <div className="font-bold text-red-900 flex items-center justify-between">
                    <span>🔴 HR &gt; 110 BPM</span>
                    <Heart className="h-3.5 w-3.5 text-red-600" />
                  </div>
                  <div className="text-[11px] text-red-700 mt-1">99.2°F | 118 BPM | 5/10</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPreset(98.8, 92, 9)}
                  className="text-left p-2.5 rounded-lg bg-red-50 hover:bg-red-100 border border-red-200 transition-all text-xs cursor-pointer"
                >
                  <div className="font-bold text-red-900 flex items-center justify-between">
                    <span>🔴 Pain &gt; 8/10</span>
                    <AlertTriangle className="h-3.5 w-3.5 text-red-600" />
                  </div>
                  <div className="text-[11px] text-red-700 mt-1">98.8°F | 92 BPM | 9/10</div>
                </button>
              </div>
            </div>

            {/* Inputs Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
              {/* Patient ID */}
              <div className="col-span-1 md:col-span-3 bg-slate-50 p-3 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Patient Identifier (PatientID)</label>
                  <p className="text-[11px] text-slate-500">Datastore Column: PatientID (Text)</p>
                </div>
                <input
                  type="text"
                  required
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none max-w-xs"
                />
              </div>

              {/* Temperature Input */}
              <div className={`p-4 rounded-xl border transition-all ${
                isTempCritical ? 'bg-red-50/80 border-red-300 ring-2 ring-red-400' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                    <Thermometer className={`h-4 w-4 ${isTempCritical ? 'text-red-600 animate-bounce' : 'text-amber-500'}`} />
                    Temperature (°F)
                  </label>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                    isTempCritical ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    Threshold: &gt; 101.0°F
                  </span>
                </div>

                <div className="flex items-center space-x-3 my-3">
                  <input
                    type="number"
                    step="0.1"
                    min="94.0"
                    max="108.0"
                    value={temperatureInput}
                    onChange={(e) => setTemperatureInput(e.target.value)}
                    className="w-28 text-2xl font-black text-slate-900 bg-white border border-slate-300 rounded-lg p-2 text-center focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <div className="flex-1">
                    <input
                      type="range"
                      min="96.0"
                      max="105.0"
                      step="0.1"
                      value={numTemp || 98.6}
                      onChange={(e) => setTemperatureInput(e.target.value)}
                      className="w-full accent-blue-600 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                      <span>96.0</span>
                      <span className="text-red-600 font-bold">101.0°F</span>
                      <span>105.0</span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-500">
                  {isTempCritical ? (
                    <span className="text-red-700 font-semibold flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> Pyrexia Alert! Exceeds 101.0°F limit.
                    </span>
                  ) : (
                    'Safe thermoregulation range (97.0 - 100.4°F)'
                  )}
                </p>
              </div>

              {/* Heart Rate Input */}
              <div className={`p-4 rounded-xl border transition-all ${
                isHRCritical ? 'bg-red-50/80 border-red-300 ring-2 ring-red-400' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                    <Heart className={`h-4 w-4 ${isHRCritical ? 'text-red-600 animate-pulse' : 'text-rose-500'}`} />
                    Heart Rate (BPM)
                  </label>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                    isHRCritical ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    Threshold: &gt; 110 BPM
                  </span>
                </div>

                <div className="flex items-center space-x-3 my-3">
                  <input
                    type="number"
                    min="40"
                    max="220"
                    value={heartRateInput}
                    onChange={(e) => setHeartRateInput(e.target.value)}
                    className="w-28 text-2xl font-black text-slate-900 bg-white border border-slate-300 rounded-lg p-2 text-center focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <div className="flex-1">
                    <input
                      type="range"
                      min="50"
                      max="160"
                      value={numHR || 75}
                      onChange={(e) => setHeartRateInput(e.target.value)}
                      className="w-full accent-blue-600 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                      <span>50</span>
                      <span className="text-red-600 font-bold">110 BPM</span>
                      <span>160</span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-500">
                  {isHRCritical ? (
                    <span className="text-red-700 font-semibold flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> Tachycardia Alert! Exceeds 110 BPM limit.
                    </span>
                  ) : (
                    'Normal resting pulse range (60 - 100 BPM)'
                  )}
                </p>
              </div>

              {/* Pain Level Input */}
              <div className={`p-4 rounded-xl border transition-all ${
                isPainCritical ? 'bg-red-50/80 border-red-300 ring-2 ring-red-400' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                    <AlertTriangle className={`h-4 w-4 ${isPainCritical ? 'text-red-600' : 'text-amber-500'}`} />
                    Pain Scale (1 - 10)
                  </label>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                    isPainCritical ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    Threshold: &gt; 8
                  </span>
                </div>

                <div className="flex items-center space-x-3 my-3">
                  <div className={`w-28 text-2xl font-black rounded-lg p-2 text-center ${getPainColor(numPain)}`}>
                    {painLevelInput || '0'} / 10
                  </div>
                  <div className="flex-1">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={numPain || 0}
                      onChange={(e) => setPainLevelInput(e.target.value)}
                      className="w-full accent-blue-600 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                      <span>0</span>
                      <span className="text-amber-600 font-bold">5</span>
                      <span className="text-red-600 font-bold">8</span>
                      <span>10</span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-500">
                  {isPainCritical ? (
                    <span className="text-red-700 font-semibold flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> Uncontrolled Pain! Exceeds score 8.
                    </span>
                  ) : (
                    'Manageable post-operative discomfort'
                  )}
                </p>
              </div>
            </div>

            {/* Live Logic Rule Preview Banner */}
            <div className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
              isAnyCritical ? 'bg-red-100 text-red-900 border-red-300' : 'bg-emerald-50 text-emerald-900 border-emerald-200'
            }`}>
              <div className="flex items-center space-x-2">
                <span className="font-bold">Clinical Logic Rule Evaluator:</span>
                <span>
                  If Temp &gt; 101 OR HR &gt; 110 OR Pain &gt; 8 &rarr;{' '}
                  <strong className={isAnyCritical ? 'text-red-700 font-black underline' : 'text-emerald-700 font-black'}>
                    {isAnyCritical ? 'CRITICAL' : 'NORMAL'}
                  </strong>
                </span>
              </div>
              <span className="text-[10px] font-mono bg-white/70 px-2 py-0.5 rounded border border-slate-300">
                Node.js Rule Active
              </span>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isAnalyzing}
                className={`w-full py-4 px-6 rounded-xl font-bold text-base text-white shadow-lg transition-all flex items-center justify-center space-x-3 cursor-pointer ${
                  isAnalyzing
                    ? 'bg-slate-400 cursor-not-allowed'
                    : isAnyCritical
                    ? 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 shadow-red-500/20'
                    : 'bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 shadow-blue-500/20'
                }`}
              >
                {isAnalyzing ? (
                  <>
                    <Sparkles className="h-5 w-5 animate-spin" />
                    <span>Evaluating Rule & Generating AI Clinical Assessment...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5 fill-current" />
                    <span>Analyze Vitals & Record to Clinical Database</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
