import React from 'react';
import { Activity, Database, LineChart, ShieldAlert, HeartPulse, Stethoscope, ChevronDown, User, LogIn, BadgeCheck } from 'lucide-react';
import { PatientProfile, UserAccount } from '../types';

interface HeaderProps {
  activeTab: 'monitor' | 'datastore' | 'analytics' | 'auth';
  setActiveTab: (tab: 'monitor' | 'datastore' | 'analytics' | 'auth') => void;
  patients: PatientProfile[];
  selectedPatient: PatientProfile;
  setSelectedPatient: (patient: PatientProfile) => void;
  criticalCount: number;
  currentUser: UserAccount | null;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  patients,
  selectedPatient,
  setSelectedPatient,
  criticalCount,
  currentUser
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Activity className="h-6 w-6 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-xl tracking-tight text-white">VitaSync</span>
                <span className="bg-blue-500/20 text-blue-400 text-xs font-semibold px-2 py-0.5 rounded border border-blue-500/30">
                  Clinical DB & AI
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Autonomous Post-Surgery Recovery & Database System
              </p>
            </div>
          </div>

          {/* Patient Switcher */}
          <div className="hidden md:flex items-center space-x-3 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
            <Stethoscope className="h-4 w-4 text-blue-400" />
            <div className="text-xs">
              <span className="text-slate-400 block text-[10px]">Active Patient</span>
              <div className="relative inline-block">
                <select
                  value={selectedPatient.id}
                  onChange={(e) => {
                    const p = patients.find((item) => item.id === e.target.value);
                    if (p) setSelectedPatient(p);
                  }}
                  className="bg-transparent text-white font-medium text-xs focus:outline-none cursor-pointer pr-4 appearance-none"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                      {p.name} ({p.id}) - POD {p.postOpDay}
                    </option>
                  ))}
                </select>
                <ChevronDown className="h-3 w-3 text-slate-400 absolute right-0 top-0.5 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* User Sign In Badge & Status Indicator */}
          <div className="flex items-center space-x-3">
            {/* User Profile Badge */}
            <button
              onClick={() => setActiveTab('auth')}
              className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer"
            >
              {currentUser ? (
                <>
                  <div className="h-5 w-5 rounded-full bg-blue-600 text-white flex items-center justify-center font-extrabold text-[10px]">
                    {currentUser.fullName.charAt(0)}
                  </div>
                  <span className="max-w-[120px] truncate">{currentUser.fullName}</span>
                  <BadgeCheck className="h-3.5 w-3.5 text-emerald-400" />
                </>
              ) : (
                <>
                  <LogIn className="h-3.5 w-3.5 text-blue-400" />
                  <span>Clinician Sign In</span>
                </>
              )}
            </button>

            {criticalCount > 0 ? (
              <div className="hidden sm:flex items-center space-x-2 bg-red-950/80 text-red-300 border border-red-800/60 px-3 py-1.5 rounded-full text-xs font-semibold animate-pulse">
                <ShieldAlert className="h-4 w-4 text-red-400" />
                <span>{criticalCount} Critical Alert{criticalCount > 1 ? 's' : ''}</span>
              </div>
            ) : (
              <div className="hidden sm:flex items-center space-x-2 bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 px-3 py-1.5 rounded-full text-xs font-medium">
                <HeartPulse className="h-4 w-4 text-emerald-400" />
                <span>All Vitals Normal</span>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 overflow-x-auto py-2 text-xs font-medium border-t border-slate-800 scrollbar-none">
          <button
            onClick={() => setActiveTab('monitor')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'monitor'
                ? 'bg-blue-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Activity className="h-4 w-4" />
            <span>Vitals Assessment</span>
          </button>

          <button
            onClick={() => setActiveTab('datastore')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'datastore'
                ? 'bg-blue-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Database className="h-4 w-4" />
            <span>Clinical Database Log</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'analytics'
                ? 'bg-blue-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <LineChart className="h-4 w-4" />
            <span>Recovery Trends</span>
          </button>

          <button
            onClick={() => setActiveTab('auth')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'auth'
                ? 'bg-blue-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <User className="h-4 w-4" />
            <span>User Sign-In / Account</span>
          </button>
        </div>
      </div>
    </header>
  );
};
