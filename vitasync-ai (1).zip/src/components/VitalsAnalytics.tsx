import React from 'react';
import { VitalsLog } from '../types';
import { LineChart, Activity, Thermometer, Heart, AlertTriangle, ShieldAlert, CheckCircle2, TrendingUp } from 'lucide-react';

interface VitalsAnalyticsProps {
  logs: VitalsLog[];
}

export const VitalsAnalytics: React.FC<VitalsAnalyticsProps> = ({ logs }) => {
  const total = logs.length;
  const criticalCount = logs.filter(l => l.status === 'Critical').length;
  const normalCount = total - criticalCount;
  const criticalPercent = total > 0 ? Math.round((criticalCount / total) * 100) : 0;

  // Average Vitals
  const avgTemp = total > 0 ? (logs.reduce((acc, curr) => acc + curr.temperature, 0) / total).toFixed(1) : '98.6';
  const avgHR = total > 0 ? Math.round(logs.reduce((acc, curr) => acc + curr.heartRate, 0) / total) : 75;
  const avgPain = total > 0 ? (logs.reduce((acc, curr) => acc + curr.painLevel, 0) / total).toFixed(1) : '3.0';

  // Chronological logs for trend chart
  const chronLogs = [...logs].reverse();

  // Calculate SVG plot points for Temperature (range 96 - 105°F)
  const getTempY = (temp: number) => {
    const min = 96, max = 105;
    const clamped = Math.max(min, Math.min(max, temp));
    return 150 - ((clamped - min) / (max - min)) * 120;
  };

  // Calculate SVG plot points for Heart Rate (range 50 - 150 BPM)
  const getHRY = (hr: number) => {
    const min = 50, max = 150;
    const clamped = Math.max(min, Math.min(max, hr));
    return 150 - ((clamped - min) / (max - min)) * 120;
  };

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Recorded Logs</div>
            <div className="text-3xl font-black text-slate-900 mt-1">{total}</div>
            <div className="text-xs text-slate-500 mt-1">Clinical Database entries</div>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Activity className="h-6 w-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Critical Trigger Rate</div>
            <div className="text-3xl font-black text-red-600 mt-1">{criticalPercent}%</div>
            <div className="text-xs text-red-600 font-semibold mt-1">{criticalCount} Critical / {normalCount} Normal</div>
          </div>
          <div className="p-3 bg-red-50 text-red-600 rounded-xl">
            <ShieldAlert className="h-6 w-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Avg Temperature</div>
            <div className="text-3xl font-black text-slate-900 mt-1">{avgTemp}°F</div>
            <div className="text-xs text-amber-600 font-semibold mt-1">Fever Limit: 101.0°F</div>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <Thermometer className="h-6 w-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Avg Heart Rate</div>
            <div className="text-3xl font-black text-slate-900 mt-1">{avgHR} <span className="text-xs font-normal text-slate-500">BPM</span></div>
            <div className="text-xs text-rose-600 font-semibold mt-1">Tachycardia Limit: 110 BPM</div>
          </div>
          <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
            <Heart className="h-6 w-6" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Temperature Trend SVG Chart */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Thermometer className="h-5 w-5 text-amber-500" />
              <h3 className="font-bold text-slate-900 text-base">Temperature Recovery Trajectory (°F)</h3>
            </div>
            <span className="text-xs font-semibold text-red-600 bg-red-50 px-2.5 py-1 rounded border border-red-200">
              Red Line = 101.0°F
            </span>
          </div>

          <div className="relative h-48 w-full bg-slate-50 rounded-lg p-2 border border-slate-200">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 400 160">
              {/* Critical threshold line at 101°F */}
              <line
                x1="0"
                y1={getTempY(101.0)}
                x2="400"
                y2={getTempY(101.0)}
                stroke="#ef4444"
                strokeWidth="2"
                strokeDasharray="4 4"
              />
              <text x="340" y={getTempY(101.0) - 5} fill="#ef4444" fontSize="10" fontWeight="bold">
                101.0°F Threshold
              </text>

              {/* Temperature trend points */}
              {chronLogs.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="3"
                  points={chronLogs.map((l, i) => {
                    const x = (i / (chronLogs.length - 1)) * 380 + 10;
                    const y = getTempY(l.temperature);
                    return `${x},${y}`;
                  }).join(' ')}
                />
              )}

              {/* Data points */}
              {chronLogs.map((l, i) => {
                const x = (i / Math.max(1, chronLogs.length - 1)) * 380 + 10;
                const y = getTempY(l.temperature);
                const isCrit = l.temperature > 101.0;
                return (
                  <g key={l.id}>
                    <circle
                      cx={x}
                      cy={y}
                      r={isCrit ? '6' : '4'}
                      fill={isCrit ? '#dc2626' : '#f59e0b'}
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                    <text
                      x={x}
                      y={y - 10}
                      fill={isCrit ? '#dc2626' : '#1e293b'}
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {l.temperature}°
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="flex justify-between text-[11px] text-slate-500 mt-2 font-mono">
            <span>Oldest Logs &rarr;</span>
            <span>Latest Vitals</span>
          </div>
        </div>

        {/* Heart Rate Trend SVG Chart */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Heart className="h-5 w-5 text-rose-500" />
              <h3 className="font-bold text-slate-900 text-base">Heart Rate Hemodynamic Trend (BPM)</h3>
            </div>
            <span className="text-xs font-semibold text-red-600 bg-red-50 px-2.5 py-1 rounded border border-red-200">
              Red Line = 110 BPM
            </span>
          </div>

          <div className="relative h-48 w-full bg-slate-50 rounded-lg p-2 border border-slate-200">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 400 160">
              {/* Critical threshold line at 110 BPM */}
              <line
                x1="0"
                y1={getHRY(110)}
                x2="400"
                y2={getHRY(110)}
                stroke="#ef4444"
                strokeWidth="2"
                strokeDasharray="4 4"
              />
              <text x="330" y={getHRY(110) - 5} fill="#ef4444" fontSize="10" fontWeight="bold">
                110 BPM Threshold
              </text>

              {/* Heart rate trend points */}
              {chronLogs.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#f43f5e"
                  strokeWidth="3"
                  points={chronLogs.map((l, i) => {
                    const x = (i / (chronLogs.length - 1)) * 380 + 10;
                    const y = getHRY(l.heartRate);
                    return `${x},${y}`;
                  }).join(' ')}
                />
              )}

              {/* Data points */}
              {chronLogs.map((l, i) => {
                const x = (i / Math.max(1, chronLogs.length - 1)) * 380 + 10;
                const y = getHRY(l.heartRate);
                const isCrit = l.heartRate > 110;
                return (
                  <g key={l.id}>
                    <circle
                      cx={x}
                      cy={y}
                      r={isCrit ? '6' : '4'}
                      fill={isCrit ? '#dc2626' : '#f43f5e'}
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                    <text
                      x={x}
                      y={y - 10}
                      fill={isCrit ? '#dc2626' : '#1e293b'}
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {l.heartRate}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="flex justify-between text-[11px] text-slate-500 mt-2 font-mono">
            <span>Oldest Logs &rarr;</span>
            <span>Latest Vitals</span>
          </div>
        </div>
      </div>
    </div>
  );
};
