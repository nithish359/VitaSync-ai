import React, { useState } from 'react';
import { Database, Search, Filter, Download, ShieldAlert, CheckCircle2, ChevronRight, Eye, RefreshCw } from 'lucide-react';
import { VitalsLog } from '../types';

interface VitalsHistoryTableProps {
  logs: VitalsLog[];
  onSelectLog: (log: VitalsLog) => void;
  onRefresh: () => void;
  isLoading: boolean;
}

export const VitalsHistoryTable: React.FC<VitalsHistoryTableProps> = ({
  logs,
  onSelectLog,
  onRefresh,
  isLoading
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Critical' | 'Normal'>('All');

  const filteredLogs = logs.filter((log) => {
    const matchesSearch = log.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          log.patientName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || log.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const exportCSV = () => {
    const headers = ['ROWID', 'PatientID', 'Temperature', 'HeartRate', 'PainLevel', 'Status', 'Timestamp'];
    const rows = logs.map(l => [
      l.rowId || l.id,
      l.patientId,
      l.temperature,
      l.heartRate,
      l.painLevel,
      l.status,
      l.timestamp
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `VitalsLogs_ClinicalDB_Export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `VitalsLogs_Database_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
      {/* Table Header Bar */}
      <div className="bg-slate-900 text-white p-4 px-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Database className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-base flex items-center gap-2">
              VitaSync Clinical Database: <span className="text-blue-400 font-mono">VitalsLogs</span>
            </h3>
            <p className="text-xs text-slate-400">
              Live records persisted in production database table schema
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-all text-xs font-semibold flex items-center space-x-1 cursor-pointer"
            title="Fetch live records"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={exportCSV}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-all text-xs font-semibold flex items-center space-x-1 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>CSV</span>
          </button>

          <button
            onClick={exportJSON}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-all text-xs font-semibold flex items-center space-x-1 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search PatientID or Name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
          <Filter className="h-4 w-4 text-slate-500" />
          <span className="text-xs text-slate-600 font-medium">Status Filter:</span>
          <div className="inline-flex rounded-lg bg-slate-200 p-0.5 text-xs">
            {(['All', 'Critical', 'Normal'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                  statusFilter === st
                    ? st === 'Critical'
                      ? 'bg-red-600 text-white'
                      : st === 'Normal'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
              <th className="py-3 px-4">Database ROWID</th>
              <th className="py-3 px-4">PatientID (Text)</th>
              <th className="py-3 px-4">Temperature (°F)</th>
              <th className="py-3 px-4">HeartRate (BPM)</th>
              <th className="py-3 px-4">PainLevel (1-10)</th>
              <th className="py-3 px-4">Status (Text)</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 text-xs text-slate-800 font-medium">
            {filteredLogs.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500 font-normal">
                  No records matching search or status filter.
                </td>
              </tr>
            ) : (
              filteredLogs.map((log) => {
                const isCrit = log.status === 'Critical';
                return (
                  <tr
                    key={log.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      isCrit ? 'bg-red-50/40' : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                      {log.rowId || 'CAT-100' + log.id.slice(-4)}
                    </td>

                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div>{log.patientId}</div>
                      <div className="text-[10px] text-slate-500 font-normal">{log.patientName}</div>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`font-black ${log.temperature > 101 ? 'text-red-600 font-extrabold' : 'text-slate-800'}`}>
                        {log.temperature}°F
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`font-black ${log.heartRate > 110 ? 'text-red-600 font-extrabold' : 'text-slate-800'}`}>
                        {log.heartRate} BPM
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`font-black px-2 py-0.5 rounded text-[11px] ${
                        log.painLevel > 8
                          ? 'bg-red-600 text-white'
                          : log.painLevel > 5
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-800'
                      }`}>
                        {log.painLevel} / 10
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      {isCrit ? (
                        <span className="inline-flex items-center space-x-1 bg-red-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm animate-pulse">
                          <ShieldAlert className="h-3 w-3" />
                          <span>Critical</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 bg-emerald-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                          <CheckCircle2 className="h-3 w-3" />
                          <span>Normal</span>
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-slate-500 text-[11px]">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onSelectLog(log)}
                        className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200 transition-all cursor-pointer"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex justify-between items-center px-6">
        <span>Showing {filteredLogs.length} of {logs.length} total entries</span>
        <span className="font-mono text-[11px]">Table: VitalsLogs</span>
      </div>
    </div>
  );
};
