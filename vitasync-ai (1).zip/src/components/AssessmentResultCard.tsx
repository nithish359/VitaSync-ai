import React from 'react';
import { ShieldAlert, CheckCircle2, Sparkles, Activity, FileText, AlertTriangle, Pill, Clock, Database, Siren, HeartPulse, User } from 'lucide-react';
import { VitalsLog } from '../types';

interface AssessmentResultCardProps {
  log: VitalsLog | null;
}

export const AssessmentResultCard: React.FC<AssessmentResultCardProps> = ({ log }) => {
  if (!log) {
    return (
      <div className="bg-slate-50 border-2 border-dashed border-slate-300 rounded-xl p-8 text-center text-slate-500">
        <Activity className="h-10 w-10 text-slate-400 mx-auto mb-3" />
        <h3 className="font-bold text-slate-700 text-base">No Vitals Assessment Conducted Yet</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
          Adjust the patient vitals parameters above and click <strong className="text-slate-800">"Analyze Vitals & Record"</strong> to execute the Catalyst serverless function and Gemini AI medical evaluation.
        </p>
      </div>
    );
  }

  const isCritical = log.status === 'Critical';

  return (
    <div
      className={`rounded-2xl transition-all duration-500 overflow-hidden shadow-2xl ${
        isCritical
          ? 'bg-red-600 text-white border-4 border-red-700 shadow-red-600/40 animate-pulse-subtle'
          : 'bg-emerald-600 text-white border-4 border-emerald-700 shadow-emerald-600/30'
      }`}
    >
      {/* Top Banner Alert Bar */}
      <div className={`px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b ${
        isCritical ? 'bg-red-700 border-red-800' : 'bg-emerald-700 border-emerald-800'
      }`}>
        <div className="flex items-center space-x-3">
          <div className={`p-2.5 rounded-full ${isCritical ? 'bg-red-900/80 text-white animate-bounce' : 'bg-emerald-800 text-white'}`}>
            {isCritical ? <Siren className="h-7 w-7 text-white" /> : <CheckCircle2 className="h-7 w-7 text-white" />}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-black text-2xl tracking-wide uppercase">
                {isCritical ? 'CRITICAL RECOVERY ALERT' : 'NORMAL RECOVERY TRAJECTORY'}
              </span>
            </div>
            <p className={`text-xs ${isCritical ? 'text-red-100' : 'text-emerald-100'} font-medium`}>
              {isCritical
                ? 'Immediate clinical triage required! Physiological limits breached.'
                : 'Patient vitals are within safe post-operative physiological parameters.'}
            </p>
          </div>
        </div>

        {/* Status Badge */}
        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <span className={`text-sm font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-md ${
            isCritical ? 'bg-white text-red-700 border-2 border-red-200' : 'bg-white text-emerald-800 border-2 border-emerald-200'
          }`}>
            {log.status}
          </span>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-6 space-y-6">
        {/* Vitals Summary Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-black/20 p-4 rounded-xl border border-white/20">
          <div className="flex items-center space-x-3 border-b sm:border-b-0 sm:border-r border-white/20 pb-2 sm:pb-0 pr-2">
            <User className="h-5 w-5 text-white/80 shrink-0" />
            <div>
              <div className="text-[10px] text-white/70 uppercase font-bold">Patient</div>
              <div className="font-extrabold text-sm text-white">{log.patientName}</div>
              <div className="text-[11px] text-white/80 font-mono">{log.patientId}</div>
            </div>
          </div>

          <div className="flex items-center space-x-3 border-b sm:border-b-0 sm:border-r border-white/20 pb-2 sm:pb-0 pr-2">
            <div className={`p-2 rounded-lg ${isCritical && log.temperature > 101 ? 'bg-red-900 text-white font-bold' : 'bg-white/10'}`}>
              <span className="text-xs font-black">°F</span>
            </div>
            <div>
              <div className="text-[10px] text-white/70 uppercase font-bold">Temperature</div>
              <div className="font-black text-xl text-white">{log.temperature}°F</div>
              <div className="text-[10px] text-white/80">Limit: &gt; 101.0°F</div>
            </div>
          </div>

          <div className="flex items-center space-x-3 border-b sm:border-b-0 sm:border-r border-white/20 pb-2 sm:pb-0 pr-2">
            <div className={`p-2 rounded-lg ${isCritical && log.heartRate > 110 ? 'bg-red-900 text-white font-bold' : 'bg-white/10'}`}>
              <HeartPulse className="h-4 w-4" />
            </div>
            <div>
              <div className="text-[10px] text-white/70 uppercase font-bold">Heart Rate</div>
              <div className="font-black text-xl text-white">{log.heartRate} <span className="text-xs font-normal">BPM</span></div>
              <div className="text-[10px] text-white/80">Limit: &gt; 110 BPM</div>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${isCritical && log.painLevel > 8 ? 'bg-red-900 text-white font-bold' : 'bg-white/10'}`}>
              <AlertTriangle className="h-4 w-4" />
            </div>
            <div>
              <div className="text-[10px] text-white/70 uppercase font-bold">Pain Score</div>
              <div className="font-black text-xl text-white">{log.painLevel} <span className="text-xs font-normal">/ 10</span></div>
              <div className="text-[10px] text-white/80">Limit: &gt; 8</div>
            </div>
          </div>
        </div>

        {/* Clinical Message & Catalyst Datastore Metadata */}
        <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 space-y-2">
          <div className="flex items-center justify-between text-xs text-white/90 font-mono">
            <span className="flex items-center space-x-1.5 font-bold">
              <Database className="h-3.5 w-3.5 text-white/80" />
              <span>Catalyst Datastore RowID: {log.rowId || 'VITAL-LOG-2026'}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Clock className="h-3.5 w-3.5 text-white/80" />
              <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
            </span>
          </div>

          <p className="text-sm font-semibold leading-relaxed text-white">
            {log.message}
          </p>
        </div>

        {/* AI Medical Assessment (Gemini Clinical Intelligence) */}
        {log.aiAssessment && (
          <div className="bg-white text-slate-900 rounded-xl p-5 shadow-lg border border-white/40 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center space-x-2">
                <Sparkles className="h-5 w-5 text-indigo-600" />
                <h4 className="font-extrabold text-base text-slate-900">
                  AI Post-Op Clinical Assessment & Action Plan
                </h4>
              </div>

              <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                isCritical
                  ? 'bg-red-100 text-red-800 border-red-300'
                  : 'bg-emerald-100 text-emerald-800 border-emerald-300'
              }`}>
                Triage Level: {log.aiAssessment.triageLevel}
              </span>
            </div>

            {/* AI Summary & Severity Gauge */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
              <div className="md:col-span-3">
                <p className="text-sm text-slate-700 font-medium leading-relaxed">
                  {log.aiAssessment.summary}
                </p>

                {/* Clinical Flags tags */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {log.aiAssessment.clinicalFlags.map((flag, idx) => (
                    <span
                      key={idx}
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md border ${
                        isCritical
                          ? 'bg-red-50 text-red-700 border-red-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}
                    >
                      • {flag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Severity Score Gauge */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                <div className="text-[10px] font-bold uppercase text-slate-500 mb-1">Acuity Index</div>
                <div className={`text-3xl font-black ${isCritical ? 'text-red-600' : 'text-emerald-600'}`}>
                  {log.aiAssessment.severityScore}
                  <span className="text-xs text-slate-400 font-normal"> / 100</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full mt-2 overflow-hidden">
                  <div
                    className={`h-full ${isCritical ? 'bg-red-600' : 'bg-emerald-500'}`}
                    style={{ width: `${Math.min(100, Math.max(10, log.aiAssessment.severityScore))}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Recommended Actions */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="h-4 w-4 text-blue-600" />
                Recommended Clinical Interventions
              </h5>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-700 font-medium">
                {log.aiAssessment.recommendedActions.map((action, idx) => (
                  <li key={idx} className="flex items-start space-x-2 bg-white p-2 rounded border border-slate-200">
                    <span className={`font-bold shrink-0 ${isCritical ? 'text-red-600' : 'text-emerald-600'}`}>
                      {idx + 1}.
                    </span>
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Medication Safety Note */}
            {log.aiAssessment.medicationAdvisory && (
              <div className="bg-indigo-50 border border-indigo-200 p-3 rounded-lg flex items-start space-x-3 text-xs text-indigo-950">
                <Pill className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold block text-indigo-900">Medication & Pain Safety Protocol:</strong>
                  <span>{log.aiAssessment.medicationAdvisory}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
