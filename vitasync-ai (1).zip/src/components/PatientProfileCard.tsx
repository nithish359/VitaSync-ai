import React from 'react';
import { User, Calendar, Bed, UserCheck, Heart, Thermometer, AlertCircle } from 'lucide-react';
import { PatientProfile } from '../types';

interface PatientProfileCardProps {
  patient: PatientProfile;
  onSelectPatient: (p: PatientProfile) => void;
  allPatients: PatientProfile[];
}

export const PatientProfileCard: React.FC<PatientProfileCardProps> = ({
  patient,
  onSelectPatient,
  allPatients
}) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Left: Patient Core Info */}
        <div className="flex items-start space-x-4">
          <div className="h-14 w-14 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center shrink-0">
            <User className="h-7 w-7 text-blue-700" />
          </div>
          <div>
            <div className="flex items-center space-x-3 flex-wrap gap-y-1">
              <h2 className="text-xl font-bold text-slate-900">{patient.name}</h2>
              <span className="bg-slate-100 text-slate-700 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-slate-200">
                ID: {patient.id}
              </span>
              <span className="bg-blue-50 text-blue-700 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-blue-200">
                Post-Op Day {patient.postOpDay} (POD {patient.postOpDay})
              </span>
            </div>
            <p className="text-sm font-medium text-slate-600 mt-1">
              <span className="font-semibold text-slate-800">Procedure:</span> {patient.surgery}
            </p>
            <div className="flex items-center space-x-4 text-xs text-slate-500 mt-2 flex-wrap gap-y-1">
              <span className="flex items-center space-x-1">
                <Calendar className="h-3.5 w-3.5 text-slate-400" />
                <span>Surgery Date: {patient.surgeryDate}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Bed className="h-3.5 w-3.5 text-slate-400" />
                <span>Room: {patient.roomNumber}</span>
              </span>
              <span className="flex items-center space-x-1">
                <UserCheck className="h-3.5 w-3.5 text-slate-400" />
                <span>Attending: {patient.attendingPhysician}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right: Baseline Vitals & Quick Switch */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 border-t lg:border-t-0 lg:border-l border-slate-200 pt-3 lg:pt-0 lg:pl-6">
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 text-xs">
            <div className="text-slate-500 font-medium mb-1 flex items-center justify-between">
              <span>Patient Baseline Vitals</span>
              <span className="text-[10px] text-slate-400">Pre-Op Normal</span>
            </div>
            <div className="flex items-center space-x-4 text-slate-700 font-semibold">
              <span className="flex items-center space-x-1">
                <Thermometer className="h-3.5 w-3.5 text-amber-500" />
                <span>{patient.baselineVitals.temp}°F</span>
              </span>
              <span className="flex items-center space-x-1">
                <Heart className="h-3.5 w-3.5 text-rose-500" />
                <span>{patient.baselineVitals.hr} BPM</span>
              </span>
              <span className="flex items-center space-x-1">
                <AlertCircle className="h-3.5 w-3.5 text-indigo-500" />
                <span>Pain: {patient.baselineVitals.pain}/10</span>
              </span>
            </div>
          </div>

          {/* Quick Select Patient */}
          <div className="flex flex-col justify-center">
            <label className="text-[11px] font-medium text-slate-500 mb-1">Switch Patient</label>
            <select
              value={patient.id}
              onChange={(e) => {
                const found = allPatients.find(p => p.id === e.target.value);
                if (found) onSelectPatient(found);
              }}
              className="bg-white border border-slate-300 text-slate-800 text-xs rounded-lg px-3 py-1.5 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              {allPatients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.id})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
