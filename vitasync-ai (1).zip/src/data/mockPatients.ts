import { PatientProfile, VitalsLog } from '../types';

export const INITIAL_PATIENTS: PatientProfile[] = [
  {
    id: 'PT-8942',
    name: 'Eleanor Vance',
    age: 58,
    gender: 'Female',
    surgery: 'Total Knee Arthroplasty (TKA)',
    surgeryDate: '2026-07-28',
    postOpDay: 2,
    attendingPhysician: 'Dr. Sarah Jenkins, MD',
    roomNumber: 'ICU-304',
    baselineVitals: { temp: 98.4, hr: 72, pain: 2 }
  },
  {
    id: 'PT-1042',
    name: 'Marcus Sterling',
    age: 64,
    gender: 'Male',
    surgery: 'Coronary Artery Bypass Graft (CABG)',
    surgeryDate: '2026-07-29',
    postOpDay: 1,
    attendingPhysician: 'Dr. Robert Chen, FACC',
    roomNumber: 'CARD-112',
    baselineVitals: { temp: 98.8, hr: 80, pain: 4 }
  },
  {
    id: 'PT-3309',
    name: 'Sophia Patel',
    age: 34,
    gender: 'Female',
    surgery: 'Laparoscopic Appendectomy',
    surgeryDate: '2026-07-29',
    postOpDay: 1,
    attendingPhysician: 'Dr. Emily Vance, FACS',
    roomNumber: 'SURG-208',
    baselineVitals: { temp: 98.6, hr: 68, pain: 1 }
  },
  {
    id: 'PT-7215',
    name: 'David Rodriguez',
    age: 71,
    gender: 'Male',
    surgery: 'Posterior Lumbar Interbody Fusion',
    surgeryDate: '2026-07-27',
    postOpDay: 3,
    attendingPhysician: 'Dr. Michael Thorne, MD',
    roomNumber: 'ORTHO-415',
    baselineVitals: { temp: 98.2, hr: 75, pain: 3 }
  }
];

export const INITIAL_VITALS_LOGS: VitalsLog[] = [
  {
    id: 'LOG-1001',
    patientId: 'PT-8942',
    patientName: 'Eleanor Vance',
    surgeryType: 'Total Knee Arthroplasty (TKA)',
    postOpDay: 2,
    temperature: 98.6,
    heartRate: 74,
    painLevel: 3,
    status: 'Normal',
    message: 'Vitals Stable: Patient PT-8942 is recovering within safe post-operative physiological parameters.',
    timestamp: '2026-07-30T03:15:00.000Z',
    rowId: '1005820000001001',
    aiAssessment: {
      summary: 'Patient exhibits normal thermoregulation and hemodynamic recovery following joint arthroplasty.',
      severityScore: 12,
      clinicalFlags: ['Wound Healing Normal', 'Normocardia'],
      recommendedActions: ['Continue scheduled oral analgesics', 'Encourage assisted physical therapy mobility'],
      medicationAdvisory: 'Acetaminophen 650mg Q6H PRN pain.',
      triageLevel: 'Routine Nursing Monitor'
    }
  },
  {
    id: 'LOG-1002',
    patientId: 'PT-1042',
    patientName: 'Marcus Sterling',
    surgeryType: 'Coronary Artery Bypass Graft (CABG)',
    postOpDay: 1,
    temperature: 101.8,
    heartRate: 118,
    painLevel: 9,
    status: 'Critical',
    message: 'CRITICAL ALERT: Immediate medical evaluation required for Patient PT-1042. Triggers: Pyrexia/High Fever (101.8°F), Tachycardia (118 BPM), Severe Breakthrough Pain (9/10).',
    timestamp: '2026-07-30T04:20:00.000Z',
    rowId: '1005820000001002',
    aiAssessment: {
      summary: 'High risk post-cardiac surgical pyrexia coupled with tachycardia and severe pain. Possible systemic inflammation or early sternal infection.',
      severityScore: 92,
      clinicalFlags: ['Fever > 101°F', 'Tachycardia > 110 BPM', 'Uncontrolled Post-Op Pain > 8'],
      recommendedActions: [
        'Stat Stat Blood Cultures x2 & CBC',
        'Notify On-Call Cardiothoracic Surgeon immediately',
        'Administer IV antipyretics per Standing Post-CABG Protocol',
        '12-Lead ECG to rule out atrial fibrillation'
      ],
      medicationAdvisory: 'IV Hydromorphone stat for severe surgical pain; IV Acetaminophen for pyrexia.',
      triageLevel: 'Emergency Triage'
    }
  },
  {
    id: 'LOG-1003',
    patientId: 'PT-3309',
    patientName: 'Sophia Patel',
    surgeryType: 'Laparoscopic Appendectomy',
    postOpDay: 1,
    temperature: 98.8,
    heartRate: 82,
    painLevel: 4,
    status: 'Normal',
    message: 'Vitals Stable: Patient PT-3309 recovering safely following minimally invasive abdominal procedure.',
    timestamp: '2026-07-30T04:45:00.000Z',
    rowId: '1005820000001003',
    aiAssessment: {
      summary: 'Vitals within normal limits post-laparoscopy. Mild abdominal gas distension pain expected.',
      severityScore: 18,
      clinicalFlags: ['Mild Post-Lap Incisional Pain'],
      recommendedActions: ['Encourage ambulation to resolve laparoscopic gas distension', 'Clear liquid diet progression'],
      medicationAdvisory: 'Ibuprofen 400mg PO with meals.',
      triageLevel: 'Routine Nursing Monitor'
    }
  }
];
