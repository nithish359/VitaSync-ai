'use strict';

const catalyst = require('zcatalyst-sdk-node');

/**
 * VitaSync AI - Zoho Catalyst Advanced I/O Function
 * Analyzes post-surgery patient vitals and persists records into Datastore table 'VitalsLogs'.
 */
module.exports = async (req, res) => {
  try {
    const app = catalyst.initialize(req);

    // Extract vitals parameters from request query or JSON body
    let body = {};
    if (req.body) {
      body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    }

    const patientId = body.patientId || req.query.patientId || 'PT-UNKNOWN';
    const temperature = parseFloat(body.temperature || req.query.temperature || 98.6);
    const heartRate = parseInt(body.heartRate || req.query.heartRate || 72, 10);
    const painLevel = parseInt(body.painLevel || req.query.painLevel || 0, 10);

    // Core Clinical Assessment Threshold Logic:
    // Temp > 101°F OR HeartRate > 110 BPM OR Pain > 8 -> 'Critical'
    const isCritical = temperature > 101.0 || heartRate > 110 || painLevel > 8;
    const status = isCritical ? 'Critical' : 'Normal';

    // Formulate clinical summary message
    let message = '';
    if (status === 'Critical') {
      const triggers = [];
      if (temperature > 101.0) triggers.push(`Pyrexia/High Fever (${temperature}°F > 101.0°F)`);
      if (heartRate > 110) triggers.push(`Tachycardia (${heartRate} BPM > 110 BPM)`);
      if (painLevel > 8) triggers.push(`Severe Breakthrough Pain (${painLevel}/10 > 8)`);
      
      message = `CRITICAL ALERT: Immediate medical evaluation required for Patient ${patientId}. Triggers: ${triggers.join(', ')}. Notify attending physician and initiate post-op emergency protocol.`;
    } else {
      message = `Vitals Stable: Patient ${patientId} is recovering within safe post-operative physiological parameters (Temp: ${temperature}°F, HR: ${heartRate} BPM, Pain: ${painLevel}/10). Continue routine care plan.`;
    }

    // Prepare row payload matching VitalsLogs Datastore Schema
    const rowData = {
      PatientID: patientId,
      Temperature: temperature,
      HeartRate: heartRate,
      PainLevel: painLevel,
      Status: status
    };

    // Insert into Catalyst Data Store table 'VitalsLogs'
    const datastore = app.datastore();
    const table = datastore.table('VitalsLogs');
    const insertedRow = await table.insertRow(rowData);

    // Return standardized response
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });

    res.end(JSON.stringify({
      success: true,
      status: status,
      patientId: patientId,
      vitals: {
        temperature,
        heartRate,
        painLevel
      },
      message: message,
      rowId: insertedRow.ROWID || 'CATALYST-ROW-' + Date.now(),
      createdTime: insertedRow.CREATEDTIME || new Date().toISOString()
    }));

  } catch (error) {
    console.error('[VitaSync AI Catalyst Function Error]:', error);
    res.writeHead(500, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(JSON.stringify({
      success: false,
      error: error.message || 'Failed to process post-op vitals'
    }));
  }
};
